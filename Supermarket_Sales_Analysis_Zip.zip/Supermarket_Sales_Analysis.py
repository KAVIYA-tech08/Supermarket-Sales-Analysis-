
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Supermarket_Sales_Analysis.csv")

print("Total Sales:", df["Total_Sales"].sum())
print("Total Orders:", df["Invoice_ID"].nunique())

print("\nCategory-wise Sales:")
print(df.groupby("Category")["Total_Sales"].sum())

print("\nBranch-wise Sales:")
print(df.groupby("Branch")["Total_Sales"].sum())
